import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-second',
  templateUrl: './second.component.html',
  styleUrls: ['./second.component.css']
})
export class SecondComponent {

  message: string = 'Hello from Second Component!';
  
  // Receiving message from FirstComponent via @Input
  @Input() parentMessage: string = '';

  // Sending message to FirstComponent via @Output
  @Output() messageEvent = new EventEmitter<string>();

  // Method to send message back to FirstComponent
  sendMessageToFirst() {
    this.messageEvent.emit('Hello First Component! Message from Second Component.');
  }
}
