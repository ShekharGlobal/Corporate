import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'pipes';


  todaydate= new Date();
  jsonval={name:'Ajay', age:'21', address:{country:"India", city:'New Delhi'}}

  months=['Jan','Feb', 'Mar', 'Apr','May','June','July','Aug','Sept','Oct','Nov','Dec'];

}
