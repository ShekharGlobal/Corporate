import { Component, OnInit } from '@angular/core';
@Component({
 selector: 'tdf',
 templateUrl: './tdf.component.html',
 
})
export class TdfComponent implements OnInit {
 constructor() { }
 ngOnInit() {
 }

 register(data:any){
 console.log(data);
 
 }}
