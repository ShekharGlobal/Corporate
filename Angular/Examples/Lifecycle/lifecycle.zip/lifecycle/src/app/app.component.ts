import { Component, OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {
  title = 'lifecycle';

  @Input() num: number = 100;

  constructor() {
    // Constructor will execute at booting time
    // Used to initialize instance members or for dependency injection
    console.log('--in constructor--');
  }

  ngOnChanges(changes: SimpleChanges): void {
    // Executes whenever changes are detected in @Input properties
    console.log('--in ngOnChanges--', changes);
  }

  ngOnInit(): void {
    // Executes after the first ngOnChanges
    // Commonly used for initialization logic like making service calls
    console.log('--in ngOnInit--');
  }

  increment(): void {
    this.num += 100;
  }

  decrement(): void {
    this.num -= 100;
  }

  ngDoCheck(): void {
    // Executes whenever Angular detects changes in the application model
    console.log('--in ngDoCheck--');
  }

  ngAfterContentInit(): void {
    // Executes after Angular projects external content into the component
    console.log('--in ngAfterContentInit--');
  }

  ngAfterContentChecked(): void {
    // Executes after every check of the projected content
    console.log('--in ngAfterContentChecked--');
  }

  ngAfterViewInit(): void {
    // Executes after the component's view and child views are initialized
    console.log('--in ngAfterViewInit--');
  }

  ngAfterViewChecked(): void {
    // Executes after every check of the component's view and child views
    console.log('--in ngAfterViewChecked--');
  }

  ngOnDestroy(): void {
    // Executes just before Angular destroys the component
    // Typically used for cleanup logic
    console.log('--in ngOnDestroy--');
  }
}
