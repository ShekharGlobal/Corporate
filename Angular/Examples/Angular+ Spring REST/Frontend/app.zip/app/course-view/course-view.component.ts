import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-course-view',
  templateUrl: './course-view.component.html',
  styleUrls: ['./course-view.component.css']
})
export class CourseViewComponent {
  router =inject(Router);
  ngOnInit(): void {
    this.router.navigateByUrl("course")
 
  }

}
