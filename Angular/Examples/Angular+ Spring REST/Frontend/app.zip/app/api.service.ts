import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  

  private baseUrl = 'http://localhost:2024/api';

  constructor(private http: HttpClient) { }

  getStudentAndCourses(): Observable<any> {
    return this.http.get(`${this.baseUrl}/view`);
  }

  createStudentAndCourses(data: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/studentAndCourses`, data);
  }

 
  updateStudentAndCourses(studentId: number, payload: any): Observable<any> {
    console.log(studentId);
    console.log(payload);
    return this.http.put(`http://localhost:2024/api/students/${studentId}`, payload);
  }

  deleteStudentAndCourses(studentId: number): Observable<any> {
    const url = `${this.baseUrl}/students/${studentId}`;
    return this.http.delete<any>(url);
  }
}
