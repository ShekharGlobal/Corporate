import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { CourseComponent } from './course/course.component';
import { CourseViewComponent } from './course-view/course-view.component';

const routes: Routes = [

  {path:'' ,component:StudentComponent },
  {path:'course' ,component: CourseComponent},
  {path:'view' ,component:CourseViewComponent },
  { path: 'home', component: StudentComponent },// Route for navigating back to the home page
  { path: 'student', component: StudentComponent },
  ];
  

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
