import { Component, inject } from '@angular/core';
import { ApiService } from '../api.service';
import { Router } from '@angular/router'; // Import Router
import { ChangeDetectorRef } from '@angular/core';
@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent {
  router =inject(Router);
  student: any; // Define the student property
  courses: any[] = [];
  editingStudentIndex: number = -1; // Initialize to -1
  showEditForm: boolean = false;
  studentName: string = '';
  updatedCourses: any[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
    this.apiService.getStudentAndCourses().subscribe(data => {
      this.courses = data;
    });
  }

  editStudent(index: number, studentName: string) {
    this.studentName = studentName; // Prefill the student name
    this.editingStudentIndex = index;
    this.showEditForm = true; // Show the form
   
  }

  saveChanges(): void {
    if (this.editingStudentIndex !== -1) {
      const studentId = this.courses[this.editingStudentIndex].id; // Assuming the student ID is stored in the 'id' property
      let courses= this.courses[this.editingStudentIndex].courses;
      //console.log(courses);
      
      const payload = {
        studentName: this.studentName,
        courses: [
         {
          courseId:courses[0].id,
          courseName:courses[0].name,
         },
         {
          courseId:courses[1].id,
          courseName:courses[1].name,

         }

        ]
      };
      // Send HTTP PUT request to update student and courses
      this.apiService.updateStudentAndCourses(studentId, payload).subscribe(
        () => {
          // Update the local data if the backend update was successful
          this.courses[this.editingStudentIndex].name = this.studentName;
          this.courses[this.editingStudentIndex].courses = this.updatedCourses.map(course => ({ name: course.courseName }));
          // Reset editingStudentIndex and showEditForm
          this.editingStudentIndex = -1;
          this.showEditForm = false;
          this.router.navigateByUrl("view")
        },
        error => {
          console.error('Failed to update student and courses:', error);
        }
      );
    }
  }
  
  

  deleteStudentAndCourses(studentId: number): void {
    this.apiService.deleteStudentAndCourses(studentId).subscribe(
      () => {
        // If deletion is successful, remove the deleted student from the list
        this.courses = this.courses.filter(student => student.id !== studentId);
        this.router.navigateByUrl("/course")
      },
      error => {
        console.error('Failed to delete student and courses:', error);
      }
    );
  }
  

  cancelEdit() {
    this.showEditForm = false; // Hide the form
    this.editingStudentIndex = -1; // Set to -1 instead of null
  }
}
