package com.example.dto;

import java.util.List;

import com.example.entity.Course;

public class StudentCourseDTO {
    private Long id;
    private String name;
    private List<Course> courses;

  
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Course> getCourses() {
        return courses;
    }


    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }
}
