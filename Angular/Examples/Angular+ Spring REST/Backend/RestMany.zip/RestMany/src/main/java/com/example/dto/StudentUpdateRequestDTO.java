package com.example.dto;



import java.util.List;

public class StudentUpdateRequestDTO {
	private String studentName;
	private List<CourseUpdateRequestDTO> courses;

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public List<CourseUpdateRequestDTO> getCourses() {
		return courses;
	}

	@Override
	public String toString() {
		return "StudentUpdateRequestDTO [studentName=" + studentName + ", courses=" + courses + "]";
	}

	public void setCourses(List<CourseUpdateRequestDTO> courses) {
		this.courses = courses;
	}
}
