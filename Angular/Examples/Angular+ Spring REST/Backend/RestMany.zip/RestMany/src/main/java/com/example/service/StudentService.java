package com.example.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.entity.Student;
import com.example.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    public Student createStudent(Student student) {
        return studentRepository.save(student);
    }

    public void updateStudent(Student student) {
        studentRepository.save(student);
    }

    public Optional<Student> getStudentById(Long id) {
        return studentRepository.findById(id);
    }

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
    
    public Optional<Student> findStudentWithCoursesById(Long id) {
        return studentRepository.findStudentWithCoursesById(id);
    }
    
    public Optional<Student> findStudentById(Long id) {
        return studentRepository.findById(id);
    }
  
    public void deleteStudent(Long id) {
        studentRepository.deleteById(id);
    }
    
    @Transactional
    public void deleteStudentAndCourses(Long studentId) {
        // Delete courses associated with the student
       // courseRepository.deleteByStudentId(studentId);
        
        // Delete the student
        studentRepository.deleteById(studentId);
    }

}
