import { Component } from '@angular/core';

@Component({
  selector: 'app-my-hello-world',
  templateUrl: './my-hello-world.component.html',
  styleUrls: ['./my-hello-world.component.css']  // Corrected: Changed 'styleUrl' to 'styleUrls'
})
export class MyHelloWorldComponent {
  message: string = 'Hello Angular!';
}