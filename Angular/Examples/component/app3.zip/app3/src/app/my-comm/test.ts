<app-card>
  <h1 #header>My Header</h1>
</app-card>
