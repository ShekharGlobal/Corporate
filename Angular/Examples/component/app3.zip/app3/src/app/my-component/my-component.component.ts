import { Component } from '@angular/core';

@Component({
  selector: 'app-my-component',
  templateUrl: './my-component.component.html',
  styleUrls: ['./my-component.component.css']
})
export class MyComponent {
  // Component logic goes here
  message2: string = 'Welcome';


  isDisabled: boolean = true;  // Component property
  //event Binding
  toggleButtonState() {
    this.isDisabled = !this.isDisabled;  // Toggle the value of isDisabled
  }


  imageUrl: string = 'assets/image/images.png';  // Relative path to the image in the assets folder

  // Function to change the image to another asset
  changeImage() {
    this.imageUrl = 'assets/image/MPHASIS.NS_BIG.png';  // Change to a different image URL in the assets folder


  }


  name: string = ''; // Component property



}