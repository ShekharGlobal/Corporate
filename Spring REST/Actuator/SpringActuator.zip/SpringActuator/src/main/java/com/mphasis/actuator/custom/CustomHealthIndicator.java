package com.mphasis.actuator.custom;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class CustomHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        boolean serviceUp = checkServiceStatus();
        if (serviceUp) {
            return Health.up().withDetail("Service Status", "Service is up and running").build();
        } else {
            return Health.down().withDetail("Service Status", "Service is down").build();
        }
    }

    private boolean checkServiceStatus() {
        // Mock service status check
        return true;  // Change to `false` to simulate service down
    }
}
