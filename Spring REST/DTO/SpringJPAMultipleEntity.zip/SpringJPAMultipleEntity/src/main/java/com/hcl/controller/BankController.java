package com.hcl.controller;

import com.hcl.dto.CustomerDTO;
import com.hcl.dto.LoanDTO;
import com.hcl.service.BankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bank")
public class BankController {

    @Autowired
    private BankService bankService;

    @PostMapping("/customer")
    public String addCustomer(@RequestBody CustomerDTO customerDTO) {
        bankService.addCustomer(customerDTO);
        return "Customer added successfully!";
    }

    @PostMapping("/customer/{id}/loan")
    public ResponseEntity<String> addLoansToCustomer(@PathVariable Long id, @RequestBody List<LoanDTO> loanDTOs) {
        bankService.allocateLoansToCustomer(id, loanDTOs);
        return ResponseEntity.ok("Loans added");
    }

    @GetMapping("/customers/{id}")
    public CustomerDTO getCustomerById(@PathVariable Long id) {
        return bankService.getCustomerByIdDTO(id);
    }
}
