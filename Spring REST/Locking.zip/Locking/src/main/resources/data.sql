INSERT INTO product (id, name, quantity, version) VALUES (3, 'Phone', 10, 0);
INSERT INTO product (id, name, quantity, version) VALUES (4, 'Laptop', 5, 0);
