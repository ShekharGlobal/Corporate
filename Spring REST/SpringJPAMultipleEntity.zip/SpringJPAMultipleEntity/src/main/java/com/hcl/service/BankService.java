package com.hcl.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.entity.Customer;
import com.hcl.entity.Loan;
import com.hcl.repository.CustomerRepository;
import com.hcl.repository.LoanRepository;

@Service
public class BankService {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private LoanRepository loanRepository;

	public void addCustomer(Customer customer) {
		customerRepository.save(customer);
	}

	public void allocateLoansToCustomer(long customerId, List<Loan> loans) {
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);
		if (optionalCustomer.isPresent()) {
			Customer customer = optionalCustomer.get();
			for (Loan loan : loans) {
				loan.setCustomer(customer);
			}
			loanRepository.saveAll(loans);
		} else {
			throw new RuntimeException("Customer not found with ID: " + customerId);
		}
	}

	 public Customer getCustomerById(Long customerId) {
	        return customerRepository.findById(customerId)
	                .orElseThrow(() -> new RuntimeException("Customer not found with ID: " + customerId));
	    }



}
