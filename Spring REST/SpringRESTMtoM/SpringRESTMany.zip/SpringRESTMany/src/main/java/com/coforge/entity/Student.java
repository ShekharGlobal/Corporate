package com.coforge.entity;

import jakarta.persistence.*;
import java.util.Set;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @ManyToMany
    @JoinTable(
    	// Join table student & Course
        name = "student_course", 
        // Foreign key in the join table pointing to Student
        joinColumns = @JoinColumn(name = "student_id"), 
        // Foreign key pointing to Course
        inverseJoinColumns = @JoinColumn(name = "course_id") 
    )
    private Set<Course> courses;

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Course> getCourses() {
        return courses;
    }

    public void setCourses(Set<Course> courses) {
        this.courses = courses;
    }
}
