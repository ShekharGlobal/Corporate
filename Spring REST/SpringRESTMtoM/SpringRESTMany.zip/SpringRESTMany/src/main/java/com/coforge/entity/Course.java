package com.coforge.entity;

import jakarta.persistence.*;
import java.util.Set;

@Entity
public class Course {

    @Id
    private Long id;

    private String name;

 // Referencing the "courses" field in Student
    @ManyToMany(mappedBy = "courses") 
    private Set<Student> students;

    // Default constructor
    public Course() {}

    // Parameterized constructor
    public Course(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<Student> getStudents() {
        return students;
    }

    public void setStudents(Set<Student> students) {
        this.students = students;
    }
}
