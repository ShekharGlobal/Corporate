package com.coforge.service;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.coforge.entity.Course;
import com.coforge.entity.Student;
import com.coforge.repository.CourseRepository;
import com.coforge.repository.StudentRepository;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Transactional
    public Student saveStudentWithCourses(Student student) {
        // Ensure that all associated courses are saved
        Set<Course> courses = student.getCourses();
        if (courses != null) {
            courses.forEach(course -> {
            	// Save course if not already present
                if (!courseRepository.existsById(course.getId())) {
                    courseRepository.save(course); 
                }
            });
        }

        // Save the student entity with the courses
        return studentRepository.save(student);
    }
}

