package com.coforge.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class AppInitializer extends AbstractAnnotationConfigDispatcherServletInitializer {

    @Override
    protected Class<?>[] getRootConfigClasses() {
        return null; // No Root Context Configuration
    }

    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class<?>[]{AppConfig.class}; // Specify the Java Config class
    }

    @Override
    protected String[] getServletMappings() {
        return new String[]{"/"}; // Map all requests to the DispatcherServlet
    }
}
