package com.cts;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
   @RequestMapping("/hello")
   public String printHello(ModelMap model) {
      model.addAttribute("message", "Welcome to Spring MVC!");
      return "hello";
   }
}