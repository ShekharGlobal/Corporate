package com.coforge.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    // Home page mapping
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // Get user by ID
    @GetMapping("/user")
    public String getUser(@RequestParam("id") String userId, Model model) {
        model.addAttribute("userId", userId);
        return "user"; // Returns user.jsp
    }

    // Add user handling (for the form in index.jsp)
    @PostMapping("/addUser")
    public String addUser(@RequestParam("name") String userName, Model model) {
        model.addAttribute("userName", userName);
        return "userAdded";
    }
}
