package com.example.criteria;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.SelectionQuery;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;
import org.hibernate.query.criteria.JpaCriteriaQuery;

public class CriteriaExample {

    public static void main(String[] args) {
        // Get a session from the SessionFactory
        Session session = HibernateUtil.getSessionFactory().openSession();

        // Start a transaction
        Transaction transaction = session.beginTransaction();

        try {
            // Create a HibernateCriteriaBuilder instance
            HibernateCriteriaBuilder builder = session.getCriteriaBuilder();

            // Create a JpaCriteriaQuery object for the Student class
            JpaCriteriaQuery<Student> criteriaQuery = builder.createQuery(Student.class);

            // Define the root for the query (equivalent to FROM Student in SQL)
            var root = criteriaQuery.from(Student.class);

            // Add filtering conditions (WHERE clause)
            var agePredicate = builder.equal(root.get("age"), 21);
            criteriaQuery.select(root).where(agePredicate);

            // Add sorting (ORDER BY clause)
            criteriaQuery.orderBy(builder.asc(root.get("name")));

            // Execute the query and get the results
            SelectionQuery<Student> query = session.createQuery(criteriaQuery);
            List<Student> students = query.getResultList();

            // Display the results
            for (Student student : students) {
                System.out.println(student);
            }

            // Commit the transaction
            transaction.commit();
        } catch (Exception e) {
            e.printStackTrace();
            if (transaction != null) {
                transaction.rollback();
            }
        } finally {
            // Close the session
            session.close();
        }
    }
}
