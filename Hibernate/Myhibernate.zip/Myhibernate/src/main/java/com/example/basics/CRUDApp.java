package com.example.basics;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class CRUDApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n=== Employee Management System ===");
            System.out.println("1. Insert Employee");
            System.out.println("2. View Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    insertEmployee(scanner);
                    break;
                case 2:
                    viewEmployee(scanner);
                    break;
                case 3:
                    updateEmployee(scanner);
                    break;
                case 4:
                    deleteEmployee(scanner);
                    break;
                case 5:
                    HibernateUtil.closeSessionFactory();
                    System.out.println("Application Exited.");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void insertEmployee(Scanner scanner) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        try {
            Employees employee = new Employees();
            System.out.print("Enter Employee ID: ");
            employee.setId(scanner.nextInt());
            System.out.print("Enter First Name: ");
            employee.setFirstName(scanner.next());
            System.out.print("Enter Last Name: ");
            employee.setLastName(scanner.next());

            session.save(employee);
            transaction.commit();
            System.out.println("Employee inserted successfully.");
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    private static void viewEmployee(Scanner scanner) {
        Session session = HibernateUtil.getSessionFactory().openSession();

        try {
            System.out.print("Enter Employee ID to view: ");
            int id = scanner.nextInt();
            Employees employee = session.get(Employees.class, id);

            if (employee != null) {
                System.out.println(employee);
            } else {
                System.out.println("Employee not found with ID: " + id);
            }
        } finally {
            session.close();
        }
    }

    private static void updateEmployee(Scanner scanner) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        try {
            System.out.print("Enter Employee ID to update: ");
            int id = scanner.nextInt();
            Employees employee = session.get(Employees.class, id);

            if (employee != null) {
                System.out.print("Enter new Last Name: ");
                employee.setLastName(scanner.next());
                session.update(employee);
                transaction.commit();
                System.out.println("Employee updated successfully.");
            } else {
                System.out.println("Employee not found with ID: " + id);
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            session.close();
        }
    }

    private static void deleteEmployee(Scanner scanner) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();

        try {
            System.out.print("Enter Employee ID to delete: ");
            int id = scanner.nextInt();
            Employees employee = session.get(Employees.class, id);

            if (employee != null) {
                session.delete(employee);
                transaction.commit();
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Employee not found with ID: " + id);
            }
        } catch (Exception e) {
            if (transaction != null) transaction.rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            session.close();
        }
    }
}
