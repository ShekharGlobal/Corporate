package com.example.uni.manytoone;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = cfg.buildSessionFactory();

        // Create a Department
        Department department = new Department();
        department.setName("HR");

        // Create Employees and associate them with the Department
        Employee emp1 = new Employee();
        emp1.setFirstName("Ajay");
        emp1.setLastName("Kumar");
        emp1.setDepartment(department);

        Employee emp2 = new Employee();
        emp2.setFirstName("Abhishek");
        emp2.setLastName("Kumar");
        emp2.setDepartment(department);

        // Save Department and Employees
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(department); // Save the parent entity first
            session.save(emp1);      // Save the child entities
            session.save(emp2);
            transaction.commit();
        }

        // Retrieve Employee with Department
        try (Session session = sessionFactory.openSession()) {
            Employee retrievedEmployee = session.get(Employee.class, 1);

            System.out.println("Employee Name: " + retrievedEmployee.getFirstName() + " " + retrievedEmployee.getLastName());
            System.out.println("Department: " + retrievedEmployee.getDepartment().getName());
        }

        sessionFactory.close();
    }
}
