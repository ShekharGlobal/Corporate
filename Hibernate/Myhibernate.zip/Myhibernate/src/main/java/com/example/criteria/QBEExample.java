package com.example.criteria;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class QBEExample {

    public static void main(String[] args) {
        // Insert a few student records to test QBE
        insertStudent(1, "John Doe", 21);
        insertStudent(2, "Jane Doe", 22);
        insertStudent(3, "Mark Smith", 21);

        // Use QBE to search for students
        queryByExample();
    }

    public static void insertStudent(int id, String name, int age) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            try {
                Student student = new Student(id, name, age);
                session.save(student);
                transaction.commit();
                System.out.println("Inserted: " + student);
            } catch (Exception e) {
                e.printStackTrace();
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void queryByExample() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction transaction = session.beginTransaction();

            try {
                // Create an example Student object
                Student exampleStudent = new Student();
                exampleStudent.setAge(21); // Only set the properties you want to filter on

                // Create a CriteriaBuilder and CriteriaQuery
                CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
                CriteriaQuery<Student> criteriaQuery = criteriaBuilder.createQuery(Student.class);
                Root<Student> root = criteriaQuery.from(Student.class);

                // Set the conditions for the query (i.e., age = 21)
                Predicate predicate = criteriaBuilder.equal(root.get("age"), exampleStudent.getAge());
                criteriaQuery.select(root).where(predicate);

                // Execute the query
                List<Student> students = session.createQuery(criteriaQuery).getResultList();

                // Display the results
                System.out.println("Students matching example:");
                for (Student student : students) {
                    System.out.println(student);
                }

                transaction.commit();
            } catch (Exception e) {
                e.printStackTrace();
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
