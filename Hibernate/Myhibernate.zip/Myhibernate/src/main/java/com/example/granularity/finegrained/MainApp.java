package com.example.granularity.finegrained;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {
    public static void main(String[] args) {
        // Create an Address
        Address address = new Address();
        address.setStreet("123 Elm St");
        address.setCity("Springfield");
        address.setState("IL");
        address.setZipCode("62704");

        // Create an Employee
        Employee employee = new Employee();
        employee.setName("Vikas Khanna");
        employee.setAddress(address);

        // Save Employee to the database
        saveEmployee(employee);

        // Fetch Employee
        Employee fetchedEmployee = getEmployeeById(1L);
        System.out.println("Fetched Employee: " + fetchedEmployee);
    }

    public static void saveEmployee(Employee employee) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(employee);
        transaction.commit();
        session.close();
        System.out.println("Employee saved successfully.");
    }

    public static Employee getEmployeeById(Long id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Employee employee = session.get(Employee.class, id);
        session.close();
        return employee;
    }
}
