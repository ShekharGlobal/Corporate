package com.example.criteria;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;
import org.hibernate.query.criteria.JpaCriteriaQuery;

public class Insert {

    public static void main(String[] args) {
        // Insert a student record
        insert();

        // Run the Criteria Query
        runCriteriaQuery();
    }

    public static void insert() {
        // Using try-with-resources to ensure the session is closed
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start a transaction
            Transaction transaction = session.beginTransaction();

            try {
                // Create a new Student object
                Student student = new Student(1, "John Doe", 21);

                // Save the student object to the database
                session.save(student);

                // Commit the transaction
                transaction.commit();
                System.out.println("Student record inserted successfully.");
            } catch (Exception e) {
                e.printStackTrace();
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void runCriteriaQuery() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Start a transaction
            Transaction transaction = session.beginTransaction();

            try {
                // Create a HibernateCriteriaBuilder instance
                HibernateCriteriaBuilder builder = session.getCriteriaBuilder();

                // Create a JpaCriteriaQuery object for the Student class
                JpaCriteriaQuery<Student> criteriaQuery = builder.createQuery(Student.class);

                // Define the root for the query (equivalent to FROM Student in SQL)
                var root = criteriaQuery.from(Student.class);

                // Add filtering conditions (WHERE clause)
                var agePredicate = builder.equal(root.get("age"), 21);
                criteriaQuery.select(root).where(agePredicate);

                // Add sorting (ORDER BY clause)
                criteriaQuery.orderBy(builder.asc(root.get("name")));

                // Execute the query and get the results
                List<Student> students = session.createQuery(criteriaQuery).getResultList();

                // Display the results
                for (Student student : students) {
                    System.out.println(student);
                }

                // Commit the transaction
                transaction.commit();
            } catch (Exception e) {
                e.printStackTrace();
                if (transaction != null) {
                    transaction.rollback();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
