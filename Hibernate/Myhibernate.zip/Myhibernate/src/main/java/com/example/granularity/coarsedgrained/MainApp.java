package com.example.granularity.coarsedgrained;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class MainApp {
    public static void main(String[] args) {
        // Create Employee
        Employee employee = new Employee();
        employee.setName("Anuj K");
        employee.setStreet("123 CP");
        employee.setCity("Rajiv Chowk");
        employee.setState("IL");
        employee.setZipCode("110001");

        // Save Employee to the database
        saveEmployee(employee);

        // Fetch Employee
        Employee fetchedEmployee = getEmployeeById(1L);
        System.out.println("Fetched Employee: " + fetchedEmployee.getName());
    }

    public static void saveEmployee(Employee employee) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        session.save(employee);
        transaction.commit();
        session.close();
        System.out.println("Employee saved successfully.");
    }

    public static Employee getEmployeeById(Long id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Employee employee = session.get(Employee.class, id);
        session.close();
        return employee;
    }
}
