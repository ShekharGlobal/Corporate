package com.example.secondlevel;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        // Create SessionFactory from hibernate.cfg.xml
        SessionFactory factory = new Configuration()
                                    .configure("hibernate.cfg.xml")
                                    .addAnnotatedClass(Student.class)
                                    .buildSessionFactory();

        // Obtain session
        Session session = factory.getCurrentSession();

        try {
            // Start a transaction
            session.beginTransaction();

            // Check if student exists in cache
            int studentId = 1;
            Student myStudent = session.get(Student.class, studentId);

            // If student is not found in the cache, it will be fetched from DB
            if (myStudent == null) {
                System.out.println("No student found with ID: " + studentId);
            } else {
                System.out.println("Student found: " + myStudent.getName());
            }

            // Commit transaction
            session.getTransaction().commit();

        } finally {
            factory.close();
        }
    }
}
