package com.example.basic.hbm;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class Insert {

	public static void main(String[] args) {
		
	   Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
	   SessionFactory factory =cfg.buildSessionFactory();
	   Session session =factory.openSession();
	   Transaction transaction= session.beginTransaction();
	   
	   Employee emp= new Employee();
	   emp.setId(102);
	   emp.setFirstName("Vikas");
	   emp.setLastName("Singh");
	   
	   session.save(emp);
	   transaction.commit();
	   factory.close();
	   session.close();
	   
	   
	   
	   
	   

	}

}
