package com.example.uni.manytomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        Configuration cfg = new Configuration().configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = cfg.buildSessionFactory();

        // Create some Courses
        Course course1 = new Course();
        course1.setName("Mathematics");

        Course course2 = new Course();
        course2.setName("Physics");

        Course course3 = new Course();
        course3.setName("Chemistry");

        // Create a Student and associate Courses
        Student student1 = new Student();
        student1.setName("Vikram Singh");
        student1.addCourse(course1);
        student1.addCourse(course2);

        Student student2 = new Student();
        student2.setName("Rahul Kapoor");
        student2.addCourse(course2);
        student2.addCourse(course3);

        // Save Students and their Courses
        try (Session session = sessionFactory.openSession()) {
            Transaction transaction = session.beginTransaction();
            session.save(student1);
            session.save(student2);
            transaction.commit();
        }

        // Retrieve a Student and their Courses
        try (Session session = sessionFactory.openSession()) {
            Student retrievedStudent = session.get(Student.class, 1);

            System.out.println("Student Name: " + retrievedStudent.getName());
            for (Course course : retrievedStudent.getCourses()) {
                System.out.println("Enrolled Course: " + course.getName());
            }
        }

        sessionFactory.close();
    }
}
