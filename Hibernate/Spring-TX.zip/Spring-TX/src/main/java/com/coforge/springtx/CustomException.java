package com.coforge.springtx;

public class CustomException extends RuntimeException {
    public CustomException(String message) {
        super(message);
    }
}
