package com.coforge.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderTackingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderTackingAppApplication.class, args);
	}

}
