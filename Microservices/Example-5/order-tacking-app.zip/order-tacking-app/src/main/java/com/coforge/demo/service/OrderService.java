package com.coforge.demo.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.coforge.demo.model.Order;

@Service
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    public Order getOrderById(String id) {
        logger.info("Fetching order details for ID: {}", id);

        // Simulating fetching data
        return new Order(id, "Sample Product", 3, 199.99);
    }
}
