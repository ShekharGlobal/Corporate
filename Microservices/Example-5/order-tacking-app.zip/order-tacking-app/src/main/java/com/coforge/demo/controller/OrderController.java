package com.coforge.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coforge.demo.model.Order;
import com.coforge.demo.service.OrderService;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private static final Logger log = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;

    // Constructor without Tracer injection
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping("/{id}")
    public Order getOrderById(@PathVariable String id) {
        // Spring Cloud Sleuth will automatically handle trace and span logging
        log.info("Fetching order details for ID: {}", id);  // Sleuth will automatically add traceId and spanId in logs

        return orderService.getOrderById(id);
    }
}
