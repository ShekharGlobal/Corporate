package com.mphasis.actuator.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * Access Actuator Endpoints:
   View all available endpoints: http://localhost:2024/actuator
   Check application health: http://localhost:2024/actuator/health
   Access custom endpoint: http://localhost:2024/actuator/custom
   Access Web Controller:
   Visit http://localhost:2024/hello 
   to see the simple controller in action.
 * 
 */
@RestController
public class DemoController {

    @GetMapping("/hello")
    public String sayHello() {
        return "Hello, Spring Boot Actuator!";
    }
}
