package com.javadream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
