package com.coforge.demo.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/products")
public class ProductController {

    @GetMapping("/{id}")
    public Map<String, String> getProduct(@PathVariable String id) {
        Map<String, String> product = new HashMap<>();
        product.put("id", id);
        product.put("name", "Product-" + id);
        product.put("price", "100");
        return product;
    }
}
