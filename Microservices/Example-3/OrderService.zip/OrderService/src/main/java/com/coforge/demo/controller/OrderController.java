package com.coforge.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.coforge.demo.feign.ProductClient;

@RestController
@RequestMapping("/orders")
public class OrderController {

    private final ProductClient productClient;

    @Autowired
    public OrderController(ProductClient productClient) {
        this.productClient = productClient;
    }

    @PostMapping("/{productId}")
    public String placeOrder(@PathVariable String productId) {
        Map<String, String> product = productClient.getProductById(productId);
        if (product == null || product.isEmpty()) {
            return "Product not found for ID: " + productId;
        }
        return "Order placed for product: " + product.get("name") + " with price: " + product.get("price");
    }
}
