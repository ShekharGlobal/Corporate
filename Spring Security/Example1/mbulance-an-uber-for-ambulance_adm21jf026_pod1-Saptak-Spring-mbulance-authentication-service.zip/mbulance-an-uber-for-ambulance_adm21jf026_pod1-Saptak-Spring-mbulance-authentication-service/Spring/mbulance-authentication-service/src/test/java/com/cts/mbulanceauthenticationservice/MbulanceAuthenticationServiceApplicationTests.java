package com.cts.mbulanceauthenticationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MbulanceAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
