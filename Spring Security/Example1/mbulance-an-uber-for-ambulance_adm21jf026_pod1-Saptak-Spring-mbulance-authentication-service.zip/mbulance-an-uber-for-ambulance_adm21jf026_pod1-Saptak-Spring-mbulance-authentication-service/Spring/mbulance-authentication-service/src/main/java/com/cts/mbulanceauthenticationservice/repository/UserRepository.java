package com.cts.mbulanceauthenticationservice.repository;


import org.springframework.data.repository.CrudRepository;

import com.cts.mbulanceauthenticationservice.model.User;


public interface UserRepository extends CrudRepository<User, Integer> {

	//User findByEmailIgnoreCaseAndPassword(String email, String password);
	
//	@Query("from User u join ContactDetails c on u.contactDetails=c.id join Address a on u.address=a.id where c.email= :email and u.password= :password")
//	User findByEmailId(@Param("email") String email, @Param("password") String password);
	
	User findByContactId(int contactId);
}
