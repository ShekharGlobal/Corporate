package com.cts.mbulanceauthenticationservice;

public class GlobalConstants {

	public static final String API_GATEWAY = "http://localhost:9090";
}
