package com.cts.mbulanceauthenticationservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;


@SpringBootApplication
public class MbulanceAuthenticationServiceApplication {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(MbulanceAuthenticationServiceApplication.class);

	public static void main(String[] args) {
		LOGGER.info("Starting Mbulance Authentication Microservice");
		SpringApplication.run(MbulanceAuthenticationServiceApplication.class, args);
		LOGGER.info("Mbulance Authentication Service Running");
	}
	
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}

}
