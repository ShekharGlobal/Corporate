package com.cts.mbulanceauthenticationservice.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.cts.mbulanceauthenticationservice.model.LoginCredentials;
import com.cts.mbulanceauthenticationservice.model.User;
import com.cts.mbulanceauthenticationservice.service.UserService;

/**
 * <h1>REST API Controller for User Registration</h1> This controller class
 * accesses the UserService class and responds to the HTTP requests to User.
 * 
 * @CrossOrigin added to allow React Application to send HTTP request
 * 
 * @author Shivji Dubey
 * @version 0.1
 * @since 11-04-2022
 */

@RestController
//@CrossOrigin("*")
@RequestMapping("/authentication")
public class UserController {
	@Autowired
	private UserService userService;

	@GetMapping("/users")
	public List<User> getAllUser() {
		return userService.retrieveAllUser();
	}

	@GetMapping("/users/{userId}")
	public Map<String, Object> getUserById(@PathVariable int userId) {
		return userService.getUserById(userId);
	}

	 @GetMapping("/users/email/{email}")
	 public Map<String, Object> getUserByContactId(@PathVariable String email) {
	 return userService.getUserFromEmail(email);
	 }

	// @PostMapping(name = "/login",consumes = MediaType.APPLICATION_JSON_VALUE)
	// public User getLoginUser(@RequestBody LoginData loginData) {
	// return userService.findUserWithEmailAndPass(loginData);
	// }

	/**
	 * Method responding to POST request to add a User
	 * 
	 * @param user
	 * @return User
	 * @throws JSONException
	 * @throws RestClientException
	 */
	@PostMapping("/register")
	@ResponseStatus(code = HttpStatus.CREATED)
	public User registerUser(@RequestBody String body) throws JSONException, ParseException {
		JSONObject jsonBody = new JSONObject(body);
		User user = new User(jsonBody.getJSONObject("user"));
		return userService.saveUser(user, jsonBody.getJSONObject("contact"), jsonBody.getJSONObject("address"));
	}

//	@PostMapping("/login")
//	public Map<String, Object> login(@RequestBody String body) throws JSONException, ParseException {
//		JSONObject jsonBody = new JSONObject(body);
//		LoginCredentials user = new LoginCredentials(jsonBody.getJSONObject("cred"));
//		return userService.authenticateUser(user);
//	}
	@GetMapping("/verify-token/{token}")
	public boolean verifyToken(@PathVariable String token) {
		boolean verifiedToken = false;
		
		if (token != null ) {
			try {
//            String token = header.substring(SecurityConstants.TOKEN_PREFIX.length()); 
            Algorithm algorithm =Algorithm.HMAC256("secret".getBytes());
            JWTVerifier verifier=JWT.require(algorithm).build();
            DecodedJWT decodedJWT = verifier.verify(token);
            String username=decodedJWT.getSubject();
            if(username!=null) {
            	verifiedToken = true;
            }
		}catch(Exception ex) {
			
		}
		}
		return verifiedToken;
	}
	
}
