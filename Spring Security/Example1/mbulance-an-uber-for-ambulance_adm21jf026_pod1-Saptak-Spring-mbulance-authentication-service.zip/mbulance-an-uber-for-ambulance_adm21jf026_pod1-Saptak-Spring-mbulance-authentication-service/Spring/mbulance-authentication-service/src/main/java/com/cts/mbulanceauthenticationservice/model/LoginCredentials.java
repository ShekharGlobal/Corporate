package com.cts.mbulanceauthenticationservice.model;

import java.text.ParseException;

import org.json.JSONException;
import org.json.JSONObject;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class LoginCredentials {
	private String email;
	private String password;
	
public LoginCredentials(JSONObject jsonObject) throws JSONException, ParseException {
		
		this.email = jsonObject.getString("email");
		this.password = jsonObject.getString("password");
	}
	
}
