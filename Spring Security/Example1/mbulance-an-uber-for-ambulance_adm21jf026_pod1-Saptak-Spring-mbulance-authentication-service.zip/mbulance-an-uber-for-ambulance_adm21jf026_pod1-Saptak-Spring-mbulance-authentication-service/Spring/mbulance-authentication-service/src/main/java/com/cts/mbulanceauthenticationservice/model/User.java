package com.cts.mbulanceauthenticationservice.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.json.JSONException;
import org.json.JSONObject;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * Model class to hold User definition
 * 
 * @author Shivji Dubey
 * @version 0.1
 * @since 09-05-2022
 */
@Entity
@Table(name="user")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(nullable=false, length=20)
	private String fullName;
	
	private int contactId;
	
	@Column(nullable=false)
	private Date dob;
	
	private int addressId;
	
	@Column(nullable=false)
	private String password;

	public User(String fullName, int contactId, Date dob, int addressId, String password) {
		super(); 
		this.fullName = fullName;
		this.contactId = contactId;
		this.dob = dob;
		this.addressId = addressId;
		this.password = password;
	}
	
	public User(JSONObject jsonObject) throws JSONException, ParseException {
		
		Date dob=new SimpleDateFormat("dd/MM/yyyy").parse(jsonObject.getString("dob"));
		
		this.fullName = jsonObject.getString("fullname");
		this.dob = dob;
		this.password = jsonObject.getString("password");
	}

		
	
}
