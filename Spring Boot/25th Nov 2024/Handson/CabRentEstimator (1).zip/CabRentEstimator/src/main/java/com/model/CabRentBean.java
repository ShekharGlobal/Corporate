package com.model;

//pojo class with required attributes,getters and setters 

// use appropriate annotation to make this class as component class
public class CabRentBean {
	
	private String cabType;
	private double rentPerHr;
	// use appropriate annotation for validating durationInHrs attribute
	private int durationInHrs;
	
	public String getCabType() {
		return cabType;
	}
	public void setCabType(String cabType) {
		this.cabType = cabType;
	}
	public double getRentPerHr() {
		return rentPerHr;
	}
	public void setRentPerHr(double rentPerHr) {
		this.rentPerHr = rentPerHr;
	}
	public int getDurationInHrs() {
		return durationInHrs;
	}
	public void setDurationInHrs(int durationInHrs) {
		this.durationInHrs = durationInHrs;
	}
	
	

}
