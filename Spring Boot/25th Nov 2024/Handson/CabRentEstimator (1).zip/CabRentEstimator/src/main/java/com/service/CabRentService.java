package com.service;

import com.model.CabRentBean;

//use appropriate annotation to configure CabRentService as a Service class
public class CabRentService {
	
	//calculate the cabRent and return the rent amount
	public double calculateCabRent (CabRentBean cabBean) {
		
		double cabRent=0.0;
		
		// fill the code
		
		return cabRent;
		
	}

}
