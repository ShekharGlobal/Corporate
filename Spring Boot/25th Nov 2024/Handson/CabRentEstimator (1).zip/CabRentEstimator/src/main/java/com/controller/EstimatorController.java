package com.controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.model.CabRentBean;


//use appropriate annotation to configure BillController as Controller
public class EstimatorController {
	
	// fill the code	  	    	    	     	      	 	

	//use appropriate annotation to configure BillController as Controller
	public String calculateCabRent(@ModelAttribute("cab") CabRentBean cabRentBean, BindingResult result,
			ModelMap model) {
		
		// fill the code
		return null;
	}
	

}
