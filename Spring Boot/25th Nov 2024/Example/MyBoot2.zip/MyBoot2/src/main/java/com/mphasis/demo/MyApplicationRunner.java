package com.mphasis.demo;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class MyApplicationRunner implements ApplicationRunner {

    /**
     * The ApplicationRunner implementation demonstrates the usage of startup arguments.
     *
     * - Non-option arguments:
     *   [] indicates no plain arguments were passed during application startup.
     *
     * - Option arguments:
     *   [spring.output.ansi.enabled] shows an internal Spring Boot argument, 
     *   which controls console output coloring.
     *
     * - Debug Mode:
     *   The code checks if an option called "debug" is passed (e.g., --debug). 
     *   If the "debug" option is present, "Debug mode is enabled." is printed. 
     *   Since "debug" is not present in the input, this message is not displayed.
     */
    
    @Override
    public void run(ApplicationArguments args) throws Exception {
        System.out.println("Hello from ApplicationRunner!");
        
        // Print non-option arguments (plain arguments)
System.out.println("Non-option arguments: " + args.getNonOptionArgs());
        
        // Print option arguments (key-value format arguments)
 System.out.println("Option arguments: " + args.getOptionNames());
        
        // Check if the "debug" option is provided
        if (args.containsOption("debug")) {
            System.out.println("Debug mode is enabled.");
        }
    }
}
