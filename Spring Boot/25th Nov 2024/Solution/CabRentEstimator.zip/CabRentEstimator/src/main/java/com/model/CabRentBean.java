package com.model;

import javax.validation.constraints.Min;

public class CabRentBean {

    private String cabType;
    private double rentPerHr;

    @Min(value = 1, message = "Duration in Hours should be minimum one")
    private int durationInHrs;

    // Getters and Setters
    public String getCabType() {
        return cabType;
    }

    public void setCabType(String cabType) {
        this.cabType = cabType;
    }

    public double getRentPerHr() {
        return rentPerHr;
    }

    public void setRentPerHr(double rentPerHr) {
        this.rentPerHr = rentPerHr;
    }

    public int getDurationInHrs() {
        return durationInHrs;
    }

    public void setDurationInHrs(int durationInHrs) {
        this.durationInHrs = durationInHrs;
    }
}
