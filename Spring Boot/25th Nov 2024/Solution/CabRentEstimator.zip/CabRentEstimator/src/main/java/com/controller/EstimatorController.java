package com.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.CabRentBean;
import com.service.CabRentService;

@Controller
public class EstimatorController {

    @Autowired
    private CabRentService cabRentService;

    // Display the initial page
    @RequestMapping(value = "/estimatorPage", method = RequestMethod.GET)
    public String estimatorPage(@ModelAttribute("cab") CabRentBean cabRentBean) {
        return "estimatorpage";
    }

    // Process the form submission
    @RequestMapping(value = "/estimatorDesk", method = RequestMethod.POST)
    public String calculateCabRent(@Valid @ModelAttribute("cab") CabRentBean cabRentBean,
                                    BindingResult result, ModelMap model) {
        // Check for validation errors
        if (result.hasErrors()) {
            return "estimatorpage";
        }

        // Calculate the estimated rent
        double estimatedRent = cabRentService.calculateCabRent(cabRentBean);
        model.addAttribute("message", "Welcome to Ranbir Cabs. Your estimated cab rent is Rs. " + estimatedRent);
        return "estimatordesk";
    }

    // Populate cab types
    @ModelAttribute("cabList")
    public Map<String, String> buildState() {
        Map<String, String> cabTypes = new HashMap<>();
        cabTypes.put("Micro-NonAC", "Micro-NonAC");
        cabTypes.put("Micro-AC", "Micro-AC");
        cabTypes.put("Mini-NonAC", "Mini-NonAC");
        cabTypes.put("Mini-AC", "Mini-AC");
        cabTypes.put("Sedan-AC", "Sedan-AC");
        cabTypes.put("Luxury", "Luxury");
        return cabTypes;
    }
}
