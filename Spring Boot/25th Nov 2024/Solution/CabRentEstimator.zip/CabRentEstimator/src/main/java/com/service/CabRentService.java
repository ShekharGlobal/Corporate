package com.service;

import org.springframework.stereotype.Service;
import com.model.CabRentBean;

@Service
public class CabRentService {
    public double calculateCabRent(CabRentBean cabBean) {
        double ratePerHour;

        switch (cabBean.getCabType()) {
            case "Micro-NonAC":
                ratePerHour = 500.0;
                break;
            case "Micro-AC":
                ratePerHour = 700.0;
                break;
            case "Mini-NonAC":
                ratePerHour = 800.0;
                break;
            case "Mini-AC":
                ratePerHour = 1000.0;
                break;
            case "Sedan-AC":
                ratePerHour = 1500.0;
                break;
            case "Luxury":
                ratePerHour = 2000.0;
                break;
            default:
                ratePerHour = 0.0;
                break;
        }

        cabBean.setRentPerHr(ratePerHour);
        return ratePerHour * cabBean.getDurationInHrs();
    }
}
