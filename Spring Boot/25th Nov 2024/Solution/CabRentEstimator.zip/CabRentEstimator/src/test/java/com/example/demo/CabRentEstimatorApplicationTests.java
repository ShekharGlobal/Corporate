/*
 * package com.example.demo;
 * 
 * 
 * import org.junit.Test;
 * 
 * 
 * public class CabRentEstimatorApplicationTests {
 * 
 * @Test public void contextLoads() { }
 * 
 * }
 */