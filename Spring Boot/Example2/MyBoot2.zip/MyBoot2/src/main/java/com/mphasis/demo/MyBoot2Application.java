package com.mphasis.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.mphasis")
public class MyBoot2Application {

	public static void main(String[] args) {
		SpringApplication.run(MyBoot2Application.class, args);
	}

}
