package com.mphasis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.service.MyService;

@RestController
public class Hello {
	
	@Autowired
	public MyService m1;
	
	@GetMapping("/h1")
	public String greet() {
		return "Hello World from SB";
	}
	
	
	@GetMapping("h2")
	public String hello() {
		return m1.hello();
	}
	
	

}
