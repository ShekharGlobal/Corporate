package com.mphasis.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {
	
	public String hello() {
		return "Good Morning";
	}

}
