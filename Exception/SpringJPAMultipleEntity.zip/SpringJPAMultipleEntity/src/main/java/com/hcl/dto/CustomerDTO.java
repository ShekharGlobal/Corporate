package com.hcl.dto;

import java.util.List;

public class CustomerDTO {
    private long customerId;
	private String customerName;
    private long customerContactNumber;
    private List<LoanDTO> loans;
    
    
    public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getCustomerContactNumber() {
		return customerContactNumber;
	}
	public void setCustomerContactNumber(long customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}
	public List<LoanDTO> getLoans() {
		return loans;
	}
	public void setLoans(List<LoanDTO> loans) {
		this.loans = loans;
	}


    
}
