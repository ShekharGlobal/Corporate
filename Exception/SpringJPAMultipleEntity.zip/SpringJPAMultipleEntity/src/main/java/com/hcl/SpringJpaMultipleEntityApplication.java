package com.hcl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaMultipleEntityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaMultipleEntityApplication.class, args);
	}

}
