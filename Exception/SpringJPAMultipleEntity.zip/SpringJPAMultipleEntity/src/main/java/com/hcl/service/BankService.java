package com.hcl.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.dto.CustomerDTO;
import com.hcl.dto.LoanDTO;
import com.hcl.entity.Customer;
import com.hcl.entity.Loan;
import com.hcl.exception.ResourceNotFoundException;
import com.hcl.repository.CustomerRepository;
import com.hcl.repository.LoanRepository;

@Service
public class BankService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private ModelMapper modelMapper;

    public void addCustomer(CustomerDTO customerDTO) {
        Customer customer = modelMapper.map(customerDTO, Customer.class);
        customerRepository.save(customer);
    }

    public void allocateLoansToCustomer(long customerId, List<LoanDTO> loanDTOs) {
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + customerId));

        List<Loan> loans = loanDTOs.stream()
                .map(dto -> {    //Lambda expression-dto is Lambda parameter
                    Loan loan = modelMapper.map(dto, Loan.class);// Converts DTO to Loan entity
                    loan.setCustomer(customer); // Links loan to the fetched customer
                    return loan;
                })
                .collect(Collectors.toList());

        loanRepository.saveAll(loans);
    }

    public CustomerDTO getCustomerByIdDTO(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with ID: " + id));

        CustomerDTO dto = modelMapper.map(customer, CustomerDTO.class);

       
        List<LoanDTO> loans = customer.getLoanList().stream()
                .map(loan -> modelMapper.map(loan, LoanDTO.class))
                .collect(Collectors.toList());
        dto.setLoans(loans);

        return dto;
    }
}
